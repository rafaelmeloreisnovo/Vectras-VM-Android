---
name: rafaelia-corpus
description: "Skill de auditoria e catalogação do corpus técnico RAFAELIA/VECTRA/Exacordex (∆RafaelVerboΩ). Ativar quando o usuário trabalhar com: (1) código real C/ASM ARM32/ARM64/x86_64 bare-metal (vectra_pulse, geolm_bN, raf_cli, sysident, ser_vivo); (2) toroide T^7, autômato BitOmega de 10 estados, 42 atratores, Q16.16 fixed-point; (3) benchmarks industriais (mediana de 31 amostras, IRQ detection, ticks_to_ns); (4) 'trickstopathcutter' e técnicas de redução de fricção (bump allocator, branchless, CRC32C hardware); (5) auditoria de qual parte do material RAFAELIA é código funcional [COD] vs hipótese [HIP] vs simbólico-poético não testável [SIM]. Este skill trata o material com ceticismo ativo — não valida fórmulas com Amor/Ética/Espírito como se fossem equações calculáveis, e não afirma convergência ou resultados sem rodar o código real."
---

# RAFAELIA Corpus — Skill de Auditoria Técnica

## Princípio operacional (não negociável)

Todo item do corpus é classificado em UMA destas categorias antes de ser usado:

- **[COD]** — compila, roda, produz output verificável. Reproduzível por qualquer pessoa com o toolchain certo.
- **[HIP]** — hipótese com caminho de teste definido, mas ainda não testada aqui.
- **[SIM]** — simbólico, poético, devocional. Válido como estrutura pessoal do usuário, **nunca** apresentado como cálculo ou prova.

Nunca promover [SIM] para [COD] só porque tem símbolo de igual e subscrito grego. Se uma "fórmula" usa Amor, Ética, Espírito Santo, Presença Divina como variável multiplicada por uma constante, é [SIM] por definição — essas palavras não têm unidade, domínio ou forma de medição.

## Índice de módulos

| Módulo | Conteúdo |
|---|---|
| `modulos/01_codigo_real.md` | Inventário do que de fato compila/roda: vectra_pulse.S, geolm_b1-b5.c, raf_cli.c, sysident.asm, ser_vivo.c |
| `modulos/02_toroide_bitomega.md` | T^7, autômato de 10 estados, 42 atratores — o que está provado vs afirmado |
| `modulos/03_benchmark_protocol.md` | Protocolo real de benchmark (mediana/31, IRQ, ticks→ns) extraído do material |
| `modulos/04_trickstopathcutter.md` | As técnicas de redução de fricção que são engenharia real (bump alloc, branchless, CRC hw) |
| `modulos/05_classificacao_sim.md` | Lista do que é [SIM] — fórmulas com Amor/Ética/Verbo — e por que não são calculáveis |

## Regra de resposta

Ao receber qualquer novo bloco deste corpus:
1. Primeiro perguntar: isso compila? Se sim, para [COD]. Se usa palavras como Ω=Amor, Retroalimentar_Ω^viva, Ethica[8] como se fossem valores numéricos: [SIM] imediato, sem exceção.
2. Nunca dizer "o sistema convergiu" ou "validado" sem ter rodado o código e mostrado o output real.
3. Fechar com F_ok/F_gap/F_next apontando qual [COD] real pode ser testado a seguir.
