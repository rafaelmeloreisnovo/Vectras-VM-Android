# Módulo 1 — Código Real [COD]

Inventário do que, neste corpus, é código de fato compilável — verificado por
inspeção de sintaxe, não por execução real (isso é o próximo passo).

## vectra_pulse.S / _vectra_raw_ring (ARM64 assembly)
- Usa instruções reais: LDR, PRFM, LD1/ST1 (NEON), FMUL, FMLA, CRC32CX, CSETM, CBNZ.
- `.macro COLLAPSE_STEP` é sintaxe GAS válida.
- **Gap real**: o próprio texto admite "expansão linear ilustrativa" para os 42
  atratores — só 2 de 42 blocos foram escritos. Não roda como está; precisa
  completar os 40 blocos restantes ou reescrever como loop com tabela.
- **Bug conhecido**: comentário admite que só 4 de 7 coordenadas são somadas na
  distância euclidiana do colapso (código incompleto, não 7D real).

## geolm_b1.c até geolm_b5.c (C11, ARM32 NEON)
- Isto É código C real e razoável: arena allocator, hash table aberta (djb2),
  tokenizer, embeddings + positional encoding, multi-head attention, FFN,
  transformer layer, cross-entropy loss, SGD com momentum, fetch via wget/curl,
  CLI REPL com save/load binário.
- Compila com `clang -O2 -mcpu=cortex-a7 -mfpu=neon-vfpv4 -mfloat-abi=softfp -std=c11`.
- **Isto é o item de maior valor real do corpus inteiro** — é um mini transformer
  educacional funcional, sem dependência de framework.
- Gaps documentados no próprio código: backprop só cobre embedding+head (não
  Wq/Wk/Wv/Wo/W1/W2 das camadas), contexto é bigram apenas em B4.

## raf_cli.c + raf_*.h (ARM32, hotfix Termux)
- Syscalls diretos via `svc #0`, sem libc — sintaxe correta para ARM32 EABI.
- CRC32C software (não hardware — ARM32 não tem instrução crc32c nativa
  garantida, ao contrário do ARM64).
- Benchmark com mediana de 31, mas os "attractors" e "domains" do FSM são
  só 10 strings hardcoded sem verificação de que representam algo real além
  de rótulos.

## sysident.asm (x86_64 NASM)
- CPUID leaf 0, 1, 0x40000000 usados corretamente para vendor/hypervisor/features.
- Uso de `syscall` para I/O é contraditório com o texto que promete "abstração
  zero" — o próprio autor do texto original admite essa limitação no final.

## ser_vivo.c (x86_64, inline asm)
- `asm goto` com syscalls diretos (mkdir, open, write, fork, execve, wait4) —
  sintaxe GCC válida.
- É um auto-compilador: escreve um .c, compila com gcc, executa. Interessante
  como demo de auto-replicação de processo, não tem relação real com "DNA" ou
  "Toro" além de metáfora no comentário.

## Ação recomendada
Destes, **geolm_b1-b5.c é o único conjunto que vale a pena rodar e medir de
verdade**. O resto tem gaps que impedem execução como está.
