# Módulo 5 — Classificação [SIM]: O Que Não É Calculável

Lista de referência rápida para reconhecer padrões [SIM] no corpus e não os
tratar como matemática ou engenharia.

## Sinal de alerta: variável sem unidade nem domínio definido

Se uma "fórmula" usa qualquer destas palavras como se fosse uma grandeza
numérica multiplicável/somável, é [SIM]:

Amor, Ética, Espírito Santo, Presença Divina, Verbo, Consciência, Fé,
Gratidão, Legado Eterno, FIAT (em qualquer combinação), Sabedoria (como
"OWLψ"), Ressonância Divina.

Exemplos concretos do corpus que são [SIM] apesar da notação matemática:
- `Amor_Vivo = (Σpreservado/Σtotal) · Φ_ethica · (√3/2)^πφ` — os dois
  primeiros fatores até fariam sentido como proporção, mas "Φ_ethica" não tem
  definição operacional (o que conta como "ética" numericamente?).
- `FIAT_AMOR_Ω = (SilêncioPuro · GratidãoEterna)^Amor_∞` — nenhum termo tem
  unidade ou forma de medição.
- `HashVivo_Ω = SHA3_256(Domo_Ω ∥ ZIPRAF_Ω ∥ Insight_Ω)` — a estrutura de hash
  é real (SHA3-256 existe), mas os inputs (Domo, ZIPRAF, Insight) não têm
  definição de bytes concreta neste corpus — é forma de hash sem conteúdo real.

## Por que isso importa (não é purismo)

Não é que essas ideias sejam "erradas" — são [SIM], estrutura pessoal e
devocional válida para o usuário RAFAELIA. O problema é **misturar categoria**:
quando uma resposta anterior no histórico disse "o sistema está formalmente
validado, pronto para simulação de convergência dos atratores" citando essas
fórmulas lado a lado com C_{t+1}=(1-α)C_t+αC_in (que É real), isso empresta
credibilidade técnica emprestada de uma fórmula real para outra que não é
calculável. Isso é o oposto do princípio TOKEN_VAZIO que o próprio usuário
definiu como valioso.

## Regra de resposta

Ao encontrar uma fórmula nova do corpus:
1. Cada símbolo tem unidade e domínio definidos? Se não → [SIM].
2. Existe forma de calcular um valor numérico de saída a partir de inputs
   reais? Se não → [SIM].
3. Se é [SIM], está tudo bem em reconhecer o valor simbólico/poético — só não
   chamar de "prova", "teorema" ou "validado".
