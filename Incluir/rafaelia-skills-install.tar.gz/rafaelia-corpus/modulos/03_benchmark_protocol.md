# Módulo 3 — Protocolo de Benchmark (o que É rigoroso neste corpus)

Diferente das fórmulas simbólicas, o protocolo de benchmark descrito em
raf_bench.h é **metodologicamente correto** e vale a pena preservar como está.

## Elementos corretos (boas práticas reais de benchmarking)

- **Warmup antes de medir** (BENCH_WARMUP=3): evita medir efeito de cold cache/branch predictor.
- **Mediana de 31 amostras, não média**: correto — média é sensível a outliers,
  mediana não. N=31 ímpar dá mediana exata sem interpolação.
- **Detecção de IRQ/interrupção do SO** via `samp[i] > mediana × 10`: heurística
  razoável para descartar amostras contaminadas por scheduler.
- **Anti dead-code-elimination** via `asm volatile("" :: "r"(resultado))`: técnica
  padrão real para impedir que o compilador otimize o benchmark inteiro fora.
- **Conversão ticks→ns condicionada a freq_hz**: correto reconhecer que em ARM32
  sem acesso a PMCCNTR confiável, cair para clock_gettime (que já retorna ns) é
  o fallback certo — evita ns_estimados falsos.

## O que precisa de cuidado ao usar

- Os "attractors" e "domains" nomeados (MATH, COSMO, QUANTUM, BIO...) no FSM
  são rótulos arbitrários de string, não correspondem a nenhuma medição real
  desses domínios — são só nomes de índice 0-9.
- Números de performance citados ("crc32c 19 GB/s", "CoreMark 18.000 pts @
  A78") não foram medidos nesta sessão — são citados de memória/estimativa,
  não de execução real. Tratar como [HIP] até rodar.

## Uso recomendado

Este protocolo (warmup+mediana+anti-DCE+IRQ-detect) é genuinamente reutilizável
para benchmarkar qualquer kernel C real do módulo 1 (especialmente os
geolm_bN.c, que têm `bench` como comando no CLI). Aplicar nele, não nas
fórmulas simbólicas.
