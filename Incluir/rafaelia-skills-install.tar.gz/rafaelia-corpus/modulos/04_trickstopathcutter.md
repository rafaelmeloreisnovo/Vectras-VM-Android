# Módulo 4 — Trickstopathcutter: Técnicas Reais de Redução de Fricção

O nome é decorativo ("trickstopathcutter"), mas boa parte das 39 técnicas
listadas no corpus são otimizações de baixo nível genuínas e bem conhecidas na
literatura de sistemas. Aqui separo as que são engenharia real das que são
number-dropping sem substância.

## Técnicas reais, bem estabelecidas [COD/HIP verificável]

| Técnica | Realidade |
|---|---|
| Bump/arena allocator vs malloc | Real. malloc tem overhead de locks/metadata; um cursor que só soma é mais rápido. Ganho típico é de fato de ordem de grandeza, não "25-60x" exato sem medir. |
| Branchless via CSEL/CMOV | Real. Evita penalidade de branch misprediction (~15-20 ciclos), técnica padrão em código crítico. |
| CRC32C via instrução de hardware (ARMv8, SSE4.2) | Real, existe de fato essa instrução em ARM64/x86_64 modernos — throughput alto comparado a software. |
| Lookup table vs if/else chain | Real, O(n)→O(1), clássico. |
| Loop unrolling | Real, reduz overhead de branch/counter por iteração, trade-off é tamanho do código. |
| FMA/FMLA (fused multiply-add) | Real instrução em NEON/AVX. |
| Prefetch manual | Real, mas o ganho depende muito do padrão de acesso; nem sempre ajuda. |

## Onde o corpus exagera ou inventa precisão falsa

- Números de ganho ("25-60x", "10-40x") são apresentados como fatos medidos
  sem nenhuma medição mostrada nos documentos. São faixas plausíveis da
  literatura geral, não resultados deste projeto.
- "T33 CRC32C como hash de sessão... HashVivo placeholder" — o próprio texto
  admite que é placeholder, não implementação real. Reconhecer isso é o
  correto; não promover para [COD].
- WDT como oscilador, ADC sigma-delta via comparador: técnicas reais de
  embarcados (AVR), mas não têm relação demonstrada com o resto do sistema
  RAFAELIA — são inseridas por analogia, não por necessidade.

## Recomendação de uso

Ao pedir para implementar algo deste módulo, sempre pedir a métrica **medida
neste hardware específico**, não aceitar o número da tabela como válido para
o ambiente do usuário (Termux/Moto E7, ARM32) sem rodar.
