---
name: casa-conceitos
description: "Skill de modelagem semântico-cognitiva do projeto RAFAELIA (∆RafaelVerboΩ). Ativar quando o usuário trabalhar com: (1) camadas de abstração L1-L7 (sinais→dados→padrões→conceitos→modelos→formal→meta-abstrato); (2) vetores semânticos/relacionais/temporais/causais/funcionais/latentes/observacionais; (3) blendings entre janelas e camadas (horizontal/vertical/diagonal/multi-janela/adaptativo); (4) compressão vetorial via ideogramas, ASCII estendido, ondulações, cores, frequências como portadores de significado; (5) Token Window / gestão de contexto e blendings de tokens; (6) hyperformas 42, tesseract, spiral √3/2, geometria da vida (60 articulações); (7) qualquer pedido de 'transformar em skills com módulos', 'matrix de relacionamento', 'usabilidade de conceitos em camadas'. Complementa (não substitui) o skill 'ta', que cobre bare-metal C/ASM e fórmulas RAFAELIA de baixo nível — use ambos quando o pedido cruzar as duas camadas."
---

# Casa de Conceitos — Skill de Modelagem Semântica RAFAELIA

## O que este skill é

Organiza a "Casa de Conceitos" (7 camadas de abstração, vetores, janelas, blendings)
como estrutura navegável para leitura, treinamento e compressão vetorial de
significado — separado do bare-metal (`ta`) e do motor dinâmico (`vectra`).

Índice de módulos (ler o relevante, não todos):

| Módulo | Arquivo | Cobre |
|---|---|---|
| 1 | `modulos/01_camadas.md` | L1-L7, invariante geométrica, complexidade/generalização |
| 2 | `modulos/02_janelas_vetores.md` | 5 janelas de leitura + 7 vetores de informação |
| 3 | `modulos/03_blendings.md` | 5 tipos de blending entre camadas/janelas |
| 4 | `modulos/04_compressao_ideogramas.md` | Ideogramas/ASCII/emoji como portadores multi-eixo de sentido |
| 5 | `modulos/05_token_window.md` | Gestão de janela de contexto, budget por camada |
| 6 | `modulos/06_geometria_hyperformas.md` | 42 hyperformas, tesseract, geometria da vida (60 articulações) |
| 7 | `modulos/07_manifold_selos.md` | Manifold real de 10D via selos bitraf64 — função, pontos calculados, distâncias, protocolo de validação (shuffle test) |
| 8 | `modulos/08_multi_leitura_tao.md` | Notação multi-leitura estilo Tao Te Ching — densidade semântica por símbolo (não economia de tokens), protocolo de leituras declaradas |
| 9 | `modulos/09_dicionario_homonimos.md` | Dicionário-base real de homônimos/polissêmicos do português (molho, banco, canto, rio...) pronto para o protocolo do módulo 8 |

## Regra de uso

1. Identifique em qual camada (L1-L7) o pedido do usuário realmente vive antes de responder.
2. Se o pedido cruza semântica ↔ bare-metal (ex: "comprimir ideograma em bitraf64"), citar módulo 4 + skill `ta` seção 7 juntos.
3. TOKEN_VAZIO > invenção: se uma camada/vetor não tiver dado real, marcar como vazio, nunca preencher com estética.
4. Fechar com F_ok/F_gap/F_next (herdado do protocolo RAFAELIA em `ta`).

---
*Skill derivado de material enviado pelo usuário (imagens: Casa de Conceitos, Token Window, Hyperformas 42, Geometria da Vida). Estrutura, não conteúdo místico — cada módulo separa [COD] executável de [SIM] simbólico.*
