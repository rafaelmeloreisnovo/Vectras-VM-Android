# Módulo 1 — Camadas de Abstração (L1-L7)

Eixo vertical: **ABSTRAÇÃO** (subir) ↔ **DETALHE** (descer)
Eixos horizontais: **COMPLEXIDADE** ↔ **GENERALIZAÇÃO**

| Nível | Nome | Conteúdo | [COD]/[SIM] |
|---|---|---|---|
| L1 | SINAIS | dados brutos, observações cruas | [COD] |
| L2 | DADOS | estruturado + não-estruturado | [COD] |
| L3 | PADRÕES | estruturais e comportamentais | [COD] se testável |
| L4 | CONCEITOS | conceitos, relações, taxonomias | [HIP]/[COD] |
| L5 | MODELOS | generativos e preditivos | [COD] se validado |
| L6 | FORMAL | lógicas, linguagens, estruturas formais | [COD] |
| L7 | META-ABSTRATA | princípios e invariantes transcendentes | [SIM] — não testável externamente |

## Invariante geométrica (aplicada a toda camada)

```
Simetria · Conservação · Equivalência · Transformação · Escala · Topologia
```

Uso prático: antes de subir de L_n para L_(n+1), perguntar qual dessas 6
propriedades se preserva na subida. Se nenhuma se preserva, a subida é
especulação, não abstração — marcar TOKEN_VAZIO.

## Elementos fundamentais (vocabulário comum a todas as camadas)

| Símbolo | Nome | Significado |
|---|---|---|
| nó | Entidade básica do sistema |
| — | aresta | Relação entre nós |
| ⬡ | hiperaresta | Relação de alta ordem (>2 nós) |
| atrator | Estado estável do sistema |
| bacia | Região de atração |
| fronteira | Limite/separação de regiões |
| fluxo | Direção de informação |
| curvatura | Distorção no espaço conceitual |

## Pipeline de leitura

```
LEITURA SISTÊMICA → TRAVESSIA/COMPOSIÇÃO/GENERALIZAÇÃO → APRENDIZADO/ADAPTAÇÃO CONTÍNUA
```

F_next típico: escolher 1 camada, aplicar 1 vetor (módulo 2), validar 1 invariante.
