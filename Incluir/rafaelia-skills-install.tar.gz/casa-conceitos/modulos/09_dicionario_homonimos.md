# Módulo 9 — Dicionário de Homônimos/Polissemia (base real, não mito)

Base verificada (gramática formal) para você construir seu próprio sistema de
notação multi-sentido usando português real — sem depender de mitos como
"crise=perigo+oportunidade" em chinês.

## Definições (para não confundir categorias)

- **Homônimas**: mesma grafia E som, origens diferentes, sentidos sem relação.
  Ex: banco (assento) / banco (instituição financeira).
- **Homógrafas**: mesma grafia, som pode variar, sentidos diferentes.
  Ex: **molho** (tempero, som fechado) / **molho** (verbo molhar, som aberto)
  / **molho** (feixe de lenha ou chaves).
- **Homófonas**: mesmo som, grafia diferente.
  Ex: conserto (reparo) / concerto (evento musical); censo / senso.
- **Polissêmicas**: mesma origem etimológica, sentidos relacionados entre si
  (diferente de homônima — aqui há parentesco de sentido).
  Ex: **língua** (órgão) → **língua** (idioma, por metáfora do órgão da fala).

## Dicionário-base (verificado, pronto para uso)

| Palavra | Sentido A | Sentido B | Sentido C | Tipo |
|---|---|---|---|---|
| molho | tempero (culinária) | feixe amarrado (lenha/chaves) | verbo molhar (eu molho) | homógrafa |
| banco | instituição financeira | assento | (verbo bancar, coloquial) | homônima |
| canto | esquina/ponta | verbo cantar | música/melodia | homônima/polissêmica |
| rio | curso de água | verbo rir (eu rio) | — | homônima |
| cedo | advérbio de tempo | verbo ceder (eu cedo) | — | homônima |
| são | contração de "santo" | sensato | verbo ser (eles são) | homônima |
| vela | objeto de cera | ato de velar (vigiar) | pano de embarcação | polissêmica |
| boca | parte do corpo | abertura/entrada (boca do túnel) | — | polissêmica |
| letra | caractere do alfabeto | texto de canção | caligrafia | polissêmica |
| cabo | parte da vassoura | patente militar | acidente geográfico | polissêmica |
| capital | cidade principal | quantia em dinheiro | — | polissêmica |
| folha | papel | parte da planta | — | polissêmica |
| manga | fruta | parte de roupa (manga da camisa) | — | homônima |
| tênis | calçado | esporte | — | polissêmica |

## Como usar no seu sistema (protocolo do módulo 8 aplicado)

```
[PALAVRA] :: [sentido_A | sentido_B | sentido_C] :: [regra_de_desambiguação]
```

Exemplo pronto:
```
CANTO :: [esquina física | ato de cantar | trecho de poema/música]
       :: regra: "o canto da sala" (substantivo espacial) vs "eu canto"
          (verbo, posição pré-verbal) vs "canto III" (numeral, contexto literário)
```

## Diferença deste módulo para o mito "crise=perigo+oportunidade"

O mito chinês tenta extrair 2 sentidos de **partes de um caractere composto**
(危 + 机) que na verdade não significam isso somados — é uma interpretação
retroativa inventada. Aqui, ao contrário: são palavras **inteiras e reais**
do português com múltiplos sentidos **documentados em dicionário e gramática
formal**, verificáveis por qualquer falante. Isso é a diferença entre [SIM]
bonito-mas-falso e [COD] real-e-checável.

## Próxima expansão possível

Se quiser, este dicionário pode crescer com:
1. Mais entradas de homônimos/polissêmicos do português (há listas extensas).
2. Cruzamento com seus próprios selos RAFAELIA (Σ,Ω,Δ...) seguindo a MESMA
   regra: cada selo só pode ter múltiplos sentidos se cada um for declarado
   explicitamente com sua regra de desambiguação — nunca "e mais infinitos
   significados por cor/frequência" (isso foi descartado no módulo 4 da
   skill por não ser decodificável).
