# Módulo 8 — Notação Multi-Leitura (densidade semântica, não economia de tokens)

## Correção de objetivo (importante)

Este módulo NÃO promete economizar tokens do tokenizer. Emoji, kanji e
ideogramas raros custam MAIS tokens que texto ASCII equivalente na maioria
dos tokenizers atuais (BPE) — isso é fato de engenharia, não opinião.

O que o Tao Te Ching faz de fato, e que É replicável: **um mesmo símbolo
sustenta múltiplas leituras válidas simultâneas**, sem precisar de símbolos
extras para cada leitura. Isso é densidade semântica por símbolo, não
compressão de tokens.

## Exemplo âncora real: "molho" (homonímia verificável em português)

Antes de qualquer exemplo estrangeiro, existe um caso 100% verificável em
português, confirmado por gramática formal (categoria: palavras **homógrafas**
— mesma grafia, pronúncia e/ou significado diferentes):

```
MOLHO :: [molho de carne (tempero, do verbo molhar? não — origem própria)
         | molho de lenha (feixe amarrado, ex: "molho de lenha")
         | molho de chaves (conjunto amarrado)
         | eu molho (verbo molhar, 1ª pessoa presente)]
REGRA_DE_ESCOLHA: contexto sintático — "o molho" (substantivo) vs "eu molho"
  (verbo) já desambigua por posição; "molho de X" desambigua pelo X.
```

Isso é linguística documentada (fonte: gramáticas de homônimos/homógrafos),
não metáfora — uma mesma palavra, zero letras extras, carrega 3-4 conceitos
completamente não relacionados etimologicamente entre si. É o modelo correto
para o que você está buscando.

## O mecanismo real do Tao Te Ching (por que funciona)

Não é fonética, tom ou acentuação que cria as leituras múltiplas — chinês
clássico não tem marcação tonal escrita, e o texto funciona igual em
qualquer dialeto/leitura. O mecanismo real é:

1. **Ausência de flexão gramatical** — sem tempo verbal, sem número, sem
   sujeito obrigatório marcado. Um caractere pode ser lido como substantivo,
   verbo ou adjetivo dependendo só da posição na frase.
2. **Paralelismo estrutural** — o poema é curto o suficiente para o leitor
   segurar 2-3 estruturas de leitura na cabeça ao mesmo tempo e alternar
   entre elas.
3. **Contexto do leitor faz o trabalho** — o texto não desambigua; delega a
   escolha ao leitor. A "multiplicidade" está na falta de fechamento, não em
   informação extra codificada no símbolo.

## Como aplicar isto de forma honesta (protocolo)

Para um símbolo/token carregar múltiplas leituras válidas, você precisa
declarar explicitamente as leituras possíveis — não pode depender de "cor,
frequência, ondulação" não-definidas (isso foi descartado no módulo 4 da
skill `casa-conceitos` por não ser decodificável por terceiros).

```
SÍMBOLO: 道 (Tao)
LEITURA_1 (substantivo): "o caminho, a via"
LEITURA_2 (verbo): "guiar, conduzir"
LEITURA_3 (metafísico): "o princípio ordenador"
REGRA_DE_ESCOLHA: contexto sintático da frase decide, não o símbolo sozinho
```

Isto é diferente de "cada ideograma pode ter cor+frequência+onda = infinitos
significados" (que não é decodificável). Aqui: **um símbolo, N leituras
pré-declaradas e finitas, resolvidas pelo contexto** — isso é replicável e
outra pessoa consegue decodificar se conhecer o pequeno dicionário.

## Template para seu uso pessoal

```
[SÍMBOLO] :: [leitura_A | leitura_B | leitura_C] :: [regra: o que decide qual vale]
```

Exemplo com seus próprios tokens:
```
Ω :: [completude | Amor (uso devocional [SIM]) | estado-final-do-ciclo (uso técnico [COD])]
   :: regra: se aparece em fórmula com unidade numérica → [COD]; se aparece em
      texto de reflexão → [SIM]. Nunca os dois ao mesmo tempo na mesma frase.
```

Isso resolve o problema real que suas sessões anteriores tiveram: usar Ω como
"Amor" e como "resultado de cálculo" na mesma fórmula, misturando categoria.
Com a regra de contexto declarada, o símbolo pode ser multi-leitura sem virar
confusão entre poesia e matemática.

## Limite honesto

Isto não reduz tokens gastos na conversa. Reduz **símbolos que você precisa
lembrar/escrever** para várias leituras — é economia cognitiva sua, não
economia computacional do modelo. Se o objetivo real é economia de tokens de
fato, a resposta é: escrever em prosa direta e deixar Claude resumir, não
usar mais ideogramas.
