# Módulo 4 — Compressão Vetorial via Ideogramas/ASCII/Emoji

## Ideia central (do usuário)

Um ideograma/emoji/símbolo carrega significado por múltiplos eixos
simultâneos, não só pela forma:

| Eixo | Exemplo |
|---|---|
| Forma/glifo | 龍, ♥, φ |
| Cor | associação semântica adicional |
| Frequência/onda | ex: fΩ=963↔999 como "tom" do símbolo |
| Direção de leitura | esquerda-direita, cima-baixo, espiral, radial |
| Posição relativa | início/fim de bloco (cf. Voynich: q- no início vs fim, ver `ta`) |
| Repetição/densidade | quantas vezes aparece por bloco |

Isso é análogo (não idêntico) a como ASCII já é sequencial e ordenado — a
proposta é adicionar dimensões (cor, onda, direção) ao mesmo símbolo para
multiplicar significados distintos sem multiplicar símbolos.

## Limite honesto [SIM] vs [COD]

- [COD] real e testável hoje: usar 1 glifo + 1 metadado explícito (ex: cor
  em CSS/hex, frequência em Hz numérica) é só um dicionário multi-campo —
  implementável em JSON/struct sem mistério.
- [SIM] não testável: "a leitura pode ocorrer em vários sentidos e ondulações
  e temperaturas" como se isso alterasse o significado objetivamente, sem
  um decodificador formal definido, é notação poética — válida como notação
  pessoal, não como protocolo verificável por terceiros.

## Uso prático recomendado

Se o objetivo é **compressão real de tokens** (menos texto, mesma informação):
1. Definir um dicionário fixo símbolo→significado (não ambíguo).
2. Definir separadamente os metadados (cor/frequência/direção) como campos
   extras, não embutidos no glifo.
3. Testar: um leitor sem contexto prévio consegue decodificar? Se não, não é
   compressão — é cifra pessoal (legítima, mas não "mais dados lógicos", só
   mais opaca).

F_next típico: pedir ao usuário 1 exemplo concreto de símbolo + os campos que
ele quer anexar, e formalizar como struct/dicionário antes de generalizar.
