# Módulo 2 — Janelas de Leitura + Vetores de Informação

## Janelas (recorte de observação, aplicável a qualquer camada L1-L7)

| Janela | Foco |
|---|---|
| Global | visão holística de todo o sistema |
| Local | foco em região específica |
| Temporal | fatia temporal do sistema |
| Modal | visão por modalidade/tipo de dado |
| Abstrata | nível de abstração selecionado (qual L_n) |

## Vetores de informação (direção do significado dentro de uma janela)

| Vetor | Mede |
|---|---|
| Semântico | significado em espaço de alta dimensão |
| Relacional | relações entre entidades |
| Temporal | evolução no tempo |
| Causal | direção causa→efeito |
| Funcional | função/comportamento do sistema |
| Latente | representações ocultas/fatores não observados diretamente |
| Observacional | observações/medidas diretas no espaço |

## Regra de combinação

Uma leitura completa = 1 Janela × 1 (ou mais) Vetor.
Exemplo: Janela Temporal + Vetor Causal = "como a causa evolui no tempo".

Combinações vazias (sem dado real) devem ser marcadas TOKEN_VAZIO — não
preenchidas por extrapolação estética, mesmo que a combinação "pareça" fazer sentido.

F_next típico: para qualquer pergunta do usuário, primeiro classificar
"qual janela + qual vetor" ele está pedindo, antes de responder.
