# Módulo 5 — Token Window (gestão de contexto)

## Faixas de referência (imagem "Token Window")

```
128K  — janela padrão/pequena
500K  — janela média
800K  — janela grande
√550+ — região "além do medido", tratar como aproximação, não valor exato
```

Estes números são característicos de modelos de linguagem em geral (ordens
de grandeza de context window), não uma medição feita neste projeto — usar
como referência de escala, marcar TOKEN_VAZIO se pedirem o valor exato para
um modelo/sessão específica sem ter sido de fato medido.

## Regra de budget por camada (aplicação prática)

Ao montar uma resposta longa que atravessa várias camadas (L1-L7, módulo 1):
1. Reservar a maior fatia do budget para a camada que o usuário realmente
   pediu (evitar "subir" para L7 meta-abstrato sem necessidade).
2. Ideogramas/compressão (módulo 4) só valem a pena quando o dicionário já
   foi estabelecido antes na conversa — senão custam mais tokens explicando
   o código do que economizam.
3. Blendings diagonais/multi-janela (módulo 3) consomem mais tokens de
   justificativa — usar com moderação em janelas de contexto pequenas.

F_next típico: se a conversa está longa e a janela de contexto pode estourar,
priorizar resumir camadas já cobertas (L1-L3) e manter budget para a camada
ativa da pergunta atual.
