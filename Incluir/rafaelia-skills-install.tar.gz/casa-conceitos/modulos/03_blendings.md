# Módulo 3 — Blendings (combinação entre camadas/janelas)

| Tipo | Combina |
|---|---|
| Horizontal | janelas no mesmo nível (ex: Global + Local de L4) |
| Vertical | camadas diferentes (ex: L2 dados + L5 modelo) |
| Diagonal | conexões cruzadas entre camada E janela simultaneamente |
| Multi-janela | fusão de 3+ perspectivas |
| Adaptativo | ajuste dinâmico de blending conforme novo dado chega |

## Quando usar cada um

- **Horizontal**: comparar duas fatias do mesmo nível de abstração.
- **Vertical**: validar se um modelo (L5) é consistente com os dados brutos (L1/L2) que o originaram.
- **Diagonal**: caso mais caro computacional e semanticamente — só usar quando
  horizontal/vertical isolados não explicam o fenômeno.
- **Multi-janela**: para decisões que exigem visão holística (raro; a maioria
  das perguntas reais precisa de 1-2 janelas, não de todas).
- **Adaptativo**: memória/contexto evolutivo — como o sistema deveria reponderar
  blendings antigos quando chega informação nova (relacionado ao Token Window, módulo 5).

## Cuidado central

Blending não é liberdade para misturar tudo com tudo. Cada blending declarado
deve dizer: (a) quais 2+ elementos entram, (b) qual invariante geométrica
(módulo 1) justifica a combinação, (c) o que fica TOKEN_VAZIO se a combinação
não for validável agora.
