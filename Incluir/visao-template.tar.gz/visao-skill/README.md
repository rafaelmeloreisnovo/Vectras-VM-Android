# visao/ — Dataset de imagens com fluxo Kanban + índice real

## Instalação (Termux)

```bash
cd ~/storage/downloads
tar -xzf visao-template.tar.gz
mv visao-skill visao
cd visao
```

## Fluxo de trabalho

```
to_do/       → coloque imagens novas aqui
doing/       → mova para cá enquanto está analisando/rotulando
done/        → mova para cá quando terminar
imgdataset/  → (opcional) versão final/curada do dataset
```

Mover arquivo entre pastas = `mv to_do/foto.png doing/foto.png` (comando normal, sem script especial).

## Gerar o índice (nome, tamanho, SHA-256, CRC32)

```bash
python3 visao_index.py .
```

Isso cria/atualiza `indice.csv` e `indice.json` na raiz de `visao/`, com uma
linha por imagem encontrada em `to_do/`, `doing/`, `done/` e `imgdataset/`.

Rode de novo sempre que mover arquivos entre pastas — o índice é
recalculado do zero a cada execução (rápido, poucos milissegundos por MB).

## O que os campos significam

| Campo | Significado |
|---|---|
| sha256 | Hash forte — identifica o arquivo por conteúdo, não por nome. Dois arquivos com sha256 igual são bit-a-bit idênticos. |
| crc32 | Checksum rápido, útil para checagem leve de corrupção (não é criptográfico). |
| pasta_atual | Em qual etapa do fluxo (to_do/doing/done/imgdataset) o arquivo está agora. |
| tamanho_bytes | Tamanho real em disco. |

## Duplicatas

O script já avisa se dois arquivos têm o mesmo `sha256` (ou seja, são
exatamente o mesmo conteúdo, mesmo que com nomes diferentes) — isso é
detecção de duplicata real, baseada em conteúdo.

## Se quiser histórico auditável de verdade (sem reinventar blockchain)

```bash
cd visao
git init
git add indice.csv indice.json
git commit -m "snapshot inicial do índice"
```

Depois de cada `python3 visao_index.py .`, rode `git add` + `git commit` de
novo. O `git log` já te dá: quem mudou o quê, quando, e diff completo —
exatamente a auditabilidade que "blockchain" prometia, sem infraestrutura extra.

## O que este template NÃO faz (por design)

- Não classifica o conteúdo das imagens (isso seria visão computacional real —
  outro projeto, com modelo de ML de verdade).
- Não é "rede de vetores multidimensional" nem "blockchain" — é um CSV com
  hash. Simples, funciona, qualquer ferramenta consegue ler.
